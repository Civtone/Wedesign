import React from "react";

const Footer = () => (
  <footer className="bg-black text-white text-center py-4">
    <p>Contact us at: civtonedesign@gmail.com | +9972023325</p>
  </footer>
);

export default Footer;
